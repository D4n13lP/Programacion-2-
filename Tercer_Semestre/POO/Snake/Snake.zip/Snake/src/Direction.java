/* Carrillo Aldana Jorge
Martinez Garcia Roberto
Pineda Ortega Daniel
 */

 
public enum Direction {
	L,U,R,D
}